# SpaceaxAI — Conversational AI dari Nol (From Scratch)

Membangun sistem AI percakapan lengkap dari nol tanpa menggunakan model/API cloud manapun. Sistem ini akan memiliki emosi, preferensi, kemampuan belajar dari internet, dan memori kontekstual.

## User Review Required

> [!IMPORTANT]
> **Skala Model**: Membangun LLM setara GPT/Claude membutuhkan miliaran dolar dan ribuan GPU. Yang akan kita bangun adalah **model transformer ~50M parameter** yang dilatih dari nol — cukup canggih untuk percakapan biasa, memiliki emosi, dan bisa belajar. Ini adalah AI yang **benar-benar milik Anda sendiri**, bukan copy model orang.

> [!WARNING]
> **Training dari nol** membutuhkan waktu lama tergantung hardware. Dengan GPU modern (RTX 3060+), training bisa selesai dalam beberapa jam. Tanpa GPU, bisa memakan waktu berhari-hari. Kami akan menyiapkan mode CPU juga.

> [!IMPORTANT]
> **Bahasa**: Apakah AI ini akan berbahasa Indonesia, Inggris, atau keduanya? Ini menentukan dataset training. Rencana saat ini mendukung **keduanya (bilingual)**.

## Open Questions

1. **Hardware**: Apakah Anda memiliki GPU NVIDIA (untuk CUDA training)? Atau hanya CPU?
2. **Nama AI**: Apakah nama AI-nya "SpaceaxAI" atau ada nama lain?
3. **Kepribadian Dasar**: Seperti apa kepribadian default AI-nya? (ramah, serius, humoris, dll?)
4. **Target Penggunaan**: Apakah ini untuk robot humanoid fisik atau software dulu?

---

## Arsitektur Sistem

```mermaid
graph TB
    subgraph "SpaceaxAI Core"
        A["🧠 Transformer Model<br/>~50M params, built from scratch"]
        B["📝 BPE Tokenizer<br/>Custom vocabulary"]
        C["💭 Emotion Engine<br/>Mood states & transitions"]
        D["🧬 Memory System<br/>Short-term & Long-term"]
        E["🌐 Web Learner<br/>Auto-scrape & digest"]
        F["❤️ Preference System<br/>Likes, dislikes, scores"]
    end

    subgraph "Training Pipeline"
        G["📚 Dataset Builder<br/>Conversation pairs"]
        H["🔄 Training Loop<br/>PyTorch from scratch"]
        I["📊 Evaluation<br/>Loss, perplexity"]
    end

    subgraph "Interface"
        J["💬 Chat Interface<br/>Terminal + Web UI"]
    end

    G --> H --> A
    B --> A
    A --> C
    A --> D
    A --> F
    E --> D
    J --> A
    C --> J
    D --> J
    F --> J
```

---

## Proposed Changes

### 1. Core Foundation — Model dari Nol

#### [NEW] [tokenizer.py](file:///home/gracecia/Dokumen/SpaceaxAi/core/tokenizer.py)
**Custom BPE (Byte-Pair Encoding) Tokenizer dari nol:**
- Implementasi BPE algorithm secara manual (tanpa library HuggingFace)
- Vocabulary size: ~16,000 tokens
- Support karakter Unicode (Bahasa Indonesia + Inggris)
- Special tokens: `<PAD>`, `<BOS>`, `<EOS>`, `<UNK>`, `<SEP>`, `<EMO_*>` (emotion tokens)
- Save/load vocabulary ke file JSON

#### [NEW] [model.py](file:///home/gracecia/Dokumen/SpaceaxAi/core/model.py)
**Transformer Model Architecture dari nol (PyTorch):**
- **Embedding Layer**: Token + Positional embeddings
- **Transformer Blocks** (8 layers):
  - Multi-Head Self-Attention (8 heads)
  - Layer Normalization (Pre-LN)
  - Feed-Forward Network (SwiGLU activation)
  - Residual connections + Dropout
- **Output Head**: Linear projection ke vocabulary
- **Config**: ~50M parameters, context length 512 tokens
- Model specs:
  - `d_model = 512`
  - `n_heads = 8`
  - `n_layers = 8`
  - `d_ff = 2048`
  - `max_seq_len = 512`
  - `vocab_size = 16000`

#### [NEW] [config.py](file:///home/gracecia/Dokumen/SpaceaxAi/core/config.py)
- Semua hyperparameter dan konfigurasi model
- Path management untuk data, checkpoint, logs

---

### 2. Training Pipeline

#### [NEW] [dataset.py](file:///home/gracecia/Dokumen/SpaceaxAi/training/dataset.py)
**Dataset Builder & Loader:**
- Parser untuk format conversation (JSON/JSONL)
- Tokenization pipeline
- DataLoader dengan padding dan batching
- Support incremental dataset (tambah data baru tanpa retrain dari awal)

#### [NEW] [trainer.py](file:///home/gracecia/Dokumen/SpaceaxAi/training/trainer.py)
**Training Loop dari nol:**
- AdamW optimizer dengan weight decay
- Cosine learning rate scheduler dengan warmup
- Gradient clipping & accumulation
- Mixed precision training (FP16) jika GPU tersedia
- Checkpoint saving & resuming
- Training metrics: loss, perplexity, learning rate
- Early stopping

#### [NEW] [generate_seed_data.py](file:///home/gracecia/Dokumen/SpaceaxAi/training/generate_seed_data.py)
**Seed Training Data Generator:**
- ~5000+ conversation pairs (Indonesia + English)
- Kategori: sapaan, emosi, opini, pengetahuan umum, humor, filosofi
- Format emotional markup: setiap response punya tag emosi
- Template-based generation untuk variasi percakapan
- Data format:
```json
{
  "conversations": [
    {
      "input": "Halo, apa kabar?",
      "response": "Halo! Kabar baik, senang bisa ngobrol denganmu!",
      "emotion": "happy",
      "topic": "greeting",
      "preference_update": {"socializing": +1}
    }
  ]
}
```

---

### 3. Emotion Engine — Sistem Emosi

#### [NEW] [emotion_engine.py](file:///home/gracecia/Dokumen/SpaceaxAi/personality/emotion_engine.py)
**Sistem Emosi Multi-dimensional:**
- **8 Emosi Dasar** (Plutchik's wheel):
  - `joy` (senang), `sadness` (sedih), `anger` (marah)
  - `fear` (takut), `surprise` (terkejut), `disgust` (jijik)
  - `trust` (percaya), `anticipation` (antisipasi)
- **Mood State**: Emosi berlangsung dan berubah gradual (bukan binary)
- **Emotion Decay**: Emosi berkurang seiring waktu secara natural
- **Trigger System**: Kata-kata/topik tertentu memicu perubahan emosi
- **Emotion Memory**: AI mengingat emosi dari percakapan sebelumnya
- **Emotion Expression**: Emosi mempengaruhi gaya bahasa response
  - Happy → lebih ceria, pakai emoji, kalimat lebih panjang
  - Sad → lebih pendek, nada rendah
  - Angry → lebih tegas, tanpa emoji
  - dll.

#### [NEW] [personality.py](file:///home/gracecia/Dokumen/SpaceaxAi/personality/personality.py)
**Sistem Kepribadian:**
- Big Five personality traits (adjustable):
  - Openness, Conscientiousness, Extraversion, Agreeableness, Neuroticism
- Personality mempengaruhi cara merespons
- Personality bisa berevolusi berdasarkan interaksi

---

### 4. Preference System — Sistem Kesukaan

#### [NEW] [preferences.py](file:///home/gracecia/Dokumen/SpaceaxAi/personality/preferences.py)
**Tracking Kesukaan/Ketidaksukaan:**
- Kategori preferensi: makanan, musik, film, hobi, topik pembicaraan, orang, tempat
- Skor preferensi: -100 (sangat tidak suka) sampai +100 (sangat suka)
- Learning: preferensi berubah berdasarkan percakapan
- Memory: AI mengingat apa yang user suka/tidak suka
- Proactive sharing: AI bisa proaktif berbagi opininya

---

### 5. Memory System — Memori Kontekstual

#### [NEW] [memory.py](file:///home/gracecia/Dokumen/SpaceaxAi/memory/memory.py)
**Dual Memory Architecture:**
- **Short-term Memory (STM)**:
  - Conversation buffer (last N turns)
  - Working context untuk percakapan aktif
- **Long-term Memory (LTM)**:
  - SQLite database untuk facts & events
  - Semantic search dengan TF-IDF vectors (built from scratch)
  - Auto-consolidation: penting dari STM → LTM
- **Episodic Memory**:
  - Mengingat percakapan spesifik dengan timestamp
  - "Kemarin kamu bilang suka pizza" → bisa recall

#### [NEW] [vector_store.py](file:///home/gracecia/Dokumen/SpaceaxAi/memory/vector_store.py)
**Simple Vector Store (tanpa library external):**
- TF-IDF vectorization dari nol
- Cosine similarity search
- Nearest neighbor retrieval
- Persistent storage ke disk

---

### 6. Web Learning — Belajar dari Internet

#### [NEW] [web_learner.py](file:///home/gracecia/Dokumen/SpaceaxAi/learning/web_learner.py)
**Auto Web Learning Pipeline:**
- Web scraping dengan `requests` + `BeautifulSoup`
- Content extraction & cleaning
- Summarization (extractive, built-in)
- Auto-categorization topik
- **Knowledge ingestion**: Hasil scraping → diproses → masuk ke seed data & memory
- Rate limiting & polite scraping
- Sources: Wikipedia, news sites, educational content

#### [NEW] [knowledge_base.py](file:///home/gracecia/Dokumen/SpaceaxAi/learning/knowledge_base.py)
**Knowledge Management:**
- Structured knowledge store (JSON-based)
- Fact verification (cross-reference multiple sources)
- Knowledge graph sederhana (entity → relation → entity)
- Auto-update: pengetahuan baru otomatis terintegrasi

#### [NEW] [auto_trainer.py](file:///home/gracecia/Dokumen/SpaceaxAi/learning/auto_trainer.py)
**Continuous Learning:**
- Fine-tune model dengan data baru dari web
- Incremental training tanpa forget knowledge lama
- Scheduled learning (bisa dijadwalkan)
- Quality filter: hanya data berkualitas yang masuk training

---

### 7. Chat Interface

#### [NEW] [chat.py](file:///home/gracecia/Dokumen/SpaceaxAi/chat.py)
**Terminal Chat Interface:**
- Interactive conversation loop
- Display emotion state & mood
- Show preference scores
- Memory recall indicator
- Colorful terminal output (rich library)

#### [NEW] [web_ui.py](file:///home/gracecia/Dokumen/SpaceaxAi/web_ui.py)
**Web Chat Interface (HTML/CSS/JS):**
- Modern chat UI
- Real-time emotion display dengan visual indicators
- Preference dashboard
- Memory browser
- Training status monitor

---

### 8. Project Setup

#### [NEW] [requirements.txt](file:///home/gracecia/Dokumen/SpaceaxAi/requirements.txt)
Dependencies (minimal, hanya yang essential):
```
torch>=2.0.0          # Neural network framework (the only major dep)
beautifulsoup4>=4.12  # Web scraping
requests>=2.31        # HTTP requests
rich>=13.0            # Terminal UI
flask>=3.0            # Web UI server
```

#### [NEW] [main.py](file:///home/gracecia/Dokumen/SpaceaxAi/main.py)
Entry point utama:
- CLI argument parser
- Mode: `train`, `chat`, `learn`, `web`
- First-run setup wizard

#### [NEW] [README.md](file:///home/gracecia/Dokumen/SpaceaxAi/README.md)
Dokumentasi lengkap penggunaan

---

## Struktur Folder Final

```
SpaceaxAi/
├── main.py                    # Entry point
├── chat.py                    # Terminal chat
├── web_ui.py                  # Web interface
├── requirements.txt
├── README.md
├── core/
│   ├── __init__.py
│   ├── config.py              # Konfigurasi
│   ├── tokenizer.py           # BPE Tokenizer
│   └── model.py               # Transformer Model
├── training/
│   ├── __init__.py
│   ├── dataset.py             # Dataset loader
│   ├── trainer.py             # Training loop
│   └── generate_seed_data.py  # Seed data generator
├── personality/
│   ├── __init__.py
│   ├── emotion_engine.py      # Sistem emosi
│   ├── personality.py         # Kepribadian
│   └── preferences.py         # Kesukaan/ketidaksukaan
├── memory/
│   ├── __init__.py
│   ├── memory.py              # Memory manager
│   └── vector_store.py        # Vector search
├── learning/
│   ├── __init__.py
│   ├── web_learner.py         # Web scraping
│   ├── knowledge_base.py      # Knowledge store
│   └── auto_trainer.py        # Continuous learning
└── data/
    ├── seed/                  # Training data
    ├── checkpoints/           # Model checkpoints
    ├── knowledge/             # Learned knowledge
    ├── memories/              # Memory database
    └── vocab/                 # Tokenizer vocabulary
```

---

## Verification Plan

### Automated Tests
1. **Tokenizer Test**: Encode → Decode roundtrip, vocabulary coverage
2. **Model Test**: Forward pass shape verification, gradient flow
3. **Training Test**: Loss decreasing over 100 steps pada sample data
4. **Emotion Test**: Emotion state transitions correct
5. **Memory Test**: Store → retrieve → search accuracy
6. **Integration Test**: Full conversation pipeline end-to-end

### Manual Verification
1. **Conversation Quality**: Chat interaktif untuk menguji naturalness
2. **Emotion Display**: Verifikasi emosi berubah sesuai konteks
3. **Web Learning**: Scrape satu artikel → verifikasi masuk knowledge base
4. **Memory Recall**: AI mengingat info dari percakapan sebelumnya
