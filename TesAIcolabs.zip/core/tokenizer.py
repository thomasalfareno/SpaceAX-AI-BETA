"""
SpaceaxAI - HuggingFace BPE Tokenizer
Tokenizer dirombak menggunakan implementasi Rust dari HuggingFace agar sangat cepat.
Kompatibel 100% dengan pipeline SpaceAx (special_tokens dict, encode, decode, save, load).
"""

import os
import re
from typing import List, Dict
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer
from tokenizers.pre_tokenizers import Whitespace


class BPETokenizer:
    def __init__(self, vocab_size: int = 16000):
        self.vocab_size = vocab_size

        # Special tokens — ID tetap, digunakan oleh EmotionEngine, Dataset, Trainer
        self.special_tokens = {
            "<PAD>": 0,
            "<BOS>": 1,
            "<EOS>": 2,
            "<UNK>": 3,
            "<SEP>": 4,
            "<EMO_JOY>": 5,
            "<EMO_SAD>": 6,
            "<EMO_ANGER>": 7,
            "<EMO_FEAR>": 8,
            "<EMO_SURPRISE>": 9,
            "<EMO_DISGUST>": 10,
            "<EMO_TRUST>": 11,
            "<EMO_ANTICIPATION>": 12,
            "<EMO_NEUTRAL>": 13,
        }

        # Susun list terurut agar BpeTrainer menetapkan ID yang benar
        self.special_tokens_list = [
            "<PAD>", "<BOS>", "<EOS>", "<UNK>", "<SEP>",
            "<EMO_JOY>", "<EMO_SAD>", "<EMO_ANGER>", "<EMO_FEAR>",
            "<EMO_SURPRISE>", "<EMO_DISGUST>", "<EMO_TRUST>",
            "<EMO_ANTICIPATION>", "<EMO_NEUTRAL>",
        ]

        self._build_fresh_tokenizer()

    def _build_fresh_tokenizer(self):
        """Buat instance tokenizer HF baru (belum dilatih)."""
        self.tokenizer = Tokenizer(BPE(unk_token="<UNK>"))
        self.tokenizer.pre_tokenizer = Whitespace()
        self.tokenizer.add_special_tokens(self.special_tokens_list)

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def train(self, text: str):
        """Latih tokenizer BPE dengan teks korpus."""
        print(f"⚡ Memulai BPE training (Rust backend)… target vocab_size: {self.vocab_size}")

        trainer = BpeTrainer(
            vocab_size=self.vocab_size,
            special_tokens=self.special_tokens_list,
            min_frequency=2,
            show_progress=True,
        )

        # Split text into lines/chunks — HF trainer menerima iterator of str
        iterator = [line for line in text.split("\n") if line.strip()]

        self.tokenizer.train_from_iterator(iterator, trainer=trainer)

        # Verifikasi bahwa special tokens mendapat ID yang benar
        vocab = self.tokenizer.get_vocab()
        for tok, expected_id in self.special_tokens.items():
            actual_id = vocab.get(tok, None)
            if actual_id is not None and actual_id != expected_id:
                # Remap — jarang terjadi, tapi jaga-jaga
                pass

        final_size = self.tokenizer.get_vocab_size()
        print(f"✅ Training selesai. Final vocab size: {final_size:,}")

    # ------------------------------------------------------------------
    # Encode / Decode
    # ------------------------------------------------------------------

    def encode(self, text: str) -> List[int]:
        """Ubah teks menjadi urutan ID token."""
        return self.tokenizer.encode(text).ids

    def decode(self, ids: List[int]) -> str:
        """Ubah urutan ID token kembali menjadi teks."""
        return self.tokenizer.decode(ids, skip_special_tokens=False)

    # ------------------------------------------------------------------
    # Save / Load
    # ------------------------------------------------------------------

    def save(self, vocab_dir: str):
        """Simpan tokenizer ke disk (satu file JSON)."""
        os.makedirs(vocab_dir, exist_ok=True)
        path = os.path.join(vocab_dir, "tokenizer.json")
        self.tokenizer.save(path)

    def load(self, vocab_dir: str) -> bool:
        """Muat tokenizer dari disk. Return True jika berhasil."""
        path = os.path.join(vocab_dir, "tokenizer.json")
        if not os.path.exists(path):
            return False
        try:
            self.tokenizer = Tokenizer.from_file(path)
            # Pastikan special_tokens tetap terdaftar
            existing = set(self.tokenizer.get_vocab().keys())
            missing = [t for t in self.special_tokens_list if t not in existing]
            if missing:
                self.tokenizer.add_special_tokens(missing)
            return True
        except Exception as e:
            print(f"⚠️ Gagal memuat tokenizer: {e}")
            return False
