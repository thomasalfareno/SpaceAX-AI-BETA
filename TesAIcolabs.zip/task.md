# SpaceaxAI — Task List

## Phase 1: Core Foundation
- [ ] Project structure & config
- [ ] Custom BPE Tokenizer
- [ ] Transformer Model Architecture
- [ ] Requirements & setup

## Phase 2: Training Pipeline
- [ ] Seed data generator (Indonesian)
- [ ] Dataset loader
- [ ] Training loop

## Phase 3: Personality & Emotion
- [ ] Emotion Engine (8 emotions)
- [ ] Personality system (Big Five)
- [ ] Preference system

## Phase 4: Memory & Learning
- [ ] Vector store (TF-IDF from scratch)
- [ ] Memory system (STM + LTM)
- [ ] Web learner
- [ ] Knowledge base
- [ ] Auto trainer

## Phase 5: Interface
- [ ] Terminal chat interface
- [ ] Web UI
- [ ] Main entry point

## Phase 6: Verification
- [ ] Training test
- [ ] Full integration test
- [ ] Conversation quality test
